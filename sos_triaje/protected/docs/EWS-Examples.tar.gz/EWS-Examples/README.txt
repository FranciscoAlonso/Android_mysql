To test PHP examples, sure you have php modules on the client machine.
For CentOS and Fedora can do the following:

$ yum install php-xml php-soap
